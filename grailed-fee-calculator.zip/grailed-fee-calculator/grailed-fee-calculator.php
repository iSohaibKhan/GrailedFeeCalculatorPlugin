<?php
/*
Plugin Name: Grailed Fee Calculator Shortcode
Plugin URI: https://sellercave.com/grailed-fee-calculator/
Description: Shortcode [grailed_fee_calculator] — responsive Grailed fee calculator. Inherits theme colors & typography via CSS variables.
Version: 1.0.1
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: grailed-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function grailed_register_assets() {
    wp_register_style('grailed-fee-calculator-css', plugins_url('assets/css/grailed-fee-calculator.css', __FILE__));
    wp_register_script('grailed-fee-calculator-js', plugins_url('assets/js/grailed-fee-calculator.js', __FILE__), array('jquery'), '1.0.2', true);

    $rates = array(
        'United States' => array('currency' => '$'),
        'Canada' => array('currency' => 'C$'),
        'United Kingdom' => array('currency' => '£'),
    );

    $config = array(
        'rates' => $rates,
        'processingRates' => array(
            'onboarded_with_stripe' => array('domestic' => 0.0398, 'international' => 0.0548),
            'not_onboarded_with_stripe' => array('domestic' => 0.0448, 'international' => 0.0648),
            'stripe_not_eligible' => array('domestic' => 0.0548, 'international' => 0.0548),
        ),
        'selling_fee_rate' => 0.09
    );

    $config = apply_filters('grailed_calc_rates', $config);

    wp_localize_script('grailed-fee-calculator-js', 'GrailedCalcData', $config);
}
add_action('wp_enqueue_scripts', 'grailed_register_assets');

function grailed_fee_calculator_shortcode($atts = array()){
    wp_enqueue_style('grailed-fee-calculator-css');
    wp_enqueue_script('grailed-fee-calculator-js');

    ob_start();
    ?>
    <div class="grailed-calc" aria-live="polite">
        <div class="card">
            <div class="grid">
                <div class="form-group country">
                    <label>Seller Location</label>
                    <select id="grailed-seller-location">
                        <option>United States</option>
                        <option>Canada</option>
                        <option>United Kingdom</option>
                    </select>
                </div>

                <div class="form-group buyer">
                    <label>Buyer Location</label>
                    <select id="grailed-buyer-location">
                        <option>Domestic</option>
                        <option>International</option>
                    </select>
                </div>

                <div class="form-group fullwidth">
                    <label>Payment Processor Status</label>
                    <select id="grailed-processor-status">
                        <option>Onboarded with Stripe</option>
                        <option>Not onboarded with Stripe</option>
                        <option>Stripe not eligible</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Selling Price</label>
                    <input id="grailed-sale-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost</label>
                    <input id="grailed-item-cost" type="number" min="0" step="0.01" />
                </div>
            </div>

            <div class="results" id="grailed-results" style="display:block;">
                <div class="result-row"><div class="label">Grailed Fee (9%):</div><div class="value" id="res-grailed">-</div></div>
                <div class="result-row"><div class="label">Payment Processing Fee:</div><div class="value" id="res-processing">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('grailed_fee_calculator', 'grailed_fee_calculator_shortcode');
