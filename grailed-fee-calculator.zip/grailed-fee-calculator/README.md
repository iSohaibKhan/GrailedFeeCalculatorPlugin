## README / Notes

* **Shortcode**: use `[grailed_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable (same UX as previous plugins). Confirmed email persists to `localStorage` so it remains confirmed on refresh.
  * **Grailed fee** = 9% of sale price.
  * **Payment Processing Fee** determined by combination of Payment Processor Status and Buyer Location as per the mapping in the localized config. (Rates are chosen to reproduce the exact numbers you provided.)
  * **Total Fees** = Grailed fee + Processing fee.
  * **Earnings** = Sale Price − Total Fees.
  * **Profit** = Earnings − Item Cost.
  * **Margin** = Profit / Earnings × 100.
* **Buyer Location visibility**: hidden automatically for Canada & United Kingdom (and Seller Location then becomes full-width on desktop), per your request.
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* You can change default rates via the `grailed_calc_rates` filter in your theme's `functions.php`.
