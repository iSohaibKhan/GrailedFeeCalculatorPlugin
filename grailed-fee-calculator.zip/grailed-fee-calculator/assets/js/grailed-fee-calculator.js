(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var cfg = window.GrailedCalcData || {};
    var rates = cfg.rates || {};
    var processingRates = cfg.processingRates || {};
    var sellingRate = cfg.selling_fee_rate || 0.09;

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.grailed-calc');
        if(!root) return;

        var sellerSelect = qs('#grailed-seller-location', root);
        var buyerSelect = qs('#grailed-buyer-location', root);
        var processorSelect = qs('#grailed-processor-status', root);
        var saleInput = qs('#grailed-sale-price', root);
        var costInput = qs('#grailed-item-cost', root);

        var results = qs('#grailed-results', root);
        var resGrailed = qs('#res-grailed', root);
        var resProcessing = qs('#res-processing', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        // show/hide buyer field when country changes
        function adjustBuyerVisibility(){
            var country = (sellerSelect.value || 'United States');
            var buyerWrap = buyerSelect.closest('.form-group');
            var sellerWrap = sellerSelect.closest('.form-group');

            if(country === 'Canada' || country === 'United Kingdom'){
                buyerWrap.style.display = 'none';
                sellerWrap.style.width = '100%';
            } else {
                buyerWrap.style.display = '';
                sellerWrap.style.width = '';
            }
        }

        sellerSelect.addEventListener('change', function(){ adjustBuyerVisibility(); calculate(); });
        buyerSelect.addEventListener('change', calculate);
        processorSelect.addEventListener('change', calculate);
        saleInput.addEventListener('input', calculate);
        costInput.addEventListener('input', calculate);

        function formatCurrency(val, symbol){ if(isNaN(val)) return '-'; return symbol + Number(val).toFixed(2); }

        function calculate(){
            var country = sellerSelect.value || 'United States';
            var buyer = buyerSelect.value || 'Domestic';
            var processorVal = processorSelect.value || 'Onboarded with Stripe';
            var sale = parseFloat(saleInput.value) || 0;
            var cost = parseFloat(costInput.value) || 0;

            var currency = (rates[country] && rates[country].currency) ? rates[country].currency : '$';

            var procKey = 'onboarded_with_stripe';
            if(processorVal.toLowerCase().indexOf('not onboarded') !== -1) procKey = 'not_onboarded_with_stripe';
            if(processorVal.toLowerCase().indexOf('stripe not eligible') !== -1) procKey = 'stripe_not_eligible';

            var buyerKey = (buyer.toLowerCase().indexOf('international') !== -1) ? 'international' : 'domestic';
            if(country === 'Canada' || country === 'United Kingdom') buyerKey = 'domestic';

            var procRate = (processingRates[procKey] && processingRates[procKey][buyerKey]) ? processingRates[procKey][buyerKey] : 0.0398;

            var grailedFee = Number((sale * sellingRate).toFixed(2));
            var processingFee = Number((sale * procRate).toFixed(2));
            var totalFees = Number((grailedFee + processingFee).toFixed(2));

            var earnings = Number((sale - totalFees).toFixed(2));
            var profit = Number((earnings - cost).toFixed(2));
            var margin = 0; if(earnings !== 0) margin = Number(((profit / earnings) * 100).toFixed(1));

            resGrailed.textContent = formatCurrency(grailedFee, currency);
            resProcessing.textContent = formatCurrency(processingFee, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            results.style.display = 'block';
        }

        // initial adjust
        adjustBuyerVisibility();
        calculate();
    });
})();
