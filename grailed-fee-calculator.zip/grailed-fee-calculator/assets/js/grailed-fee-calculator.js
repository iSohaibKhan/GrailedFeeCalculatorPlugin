(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var cfg = window.GrailedCalcData || {};
    var rates = cfg.rates || {};
    var processingRates = cfg.processingRates || {};
    var sellingRate = cfg.selling_fee_rate || 0.09;

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.grailed-calc');
        if(!root) return;

        var email = qs('#grailed-email', root);
        var confirmBtn = qs('#grailed-confirm-email', root);
        var clearBtn = qs('#grailed-clear', root);

        var sellerSelect = qs('#grailed-seller-location', root);
        var buyerSelect = qs('#grailed-buyer-location', root);
        var processorSelect = qs('#grailed-processor-status', root);
        var saleInput = qs('#grailed-sale-price', root);
        var costInput = qs('#grailed-item-cost', root);

        var results = qs('#grailed-results', root);
        var resGrailed = qs('#res-grailed', root);
        var resProcessing = qs('#res-processing', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        function setDisabledState(disabled){
            [sellerSelect, buyerSelect, processorSelect, saleInput, costInput].forEach(function(i){ if(i) i.disabled = disabled; });
            if(disabled){ root.classList.add('grailed-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('grailed-disabled'); results.style.display = 'block'; }
        }

        // restore email state
        var savedEmail = localStorage.getItem('grailed_email') || '';
        var confirmed = localStorage.getItem('grailed_email_confirmed') === '1';
        if(savedEmail){ email.value = savedEmail; }
        if(confirmed && savedEmail){ confirmBtn.textContent = '✔ Email Confirmed'; confirmBtn.disabled = true; setDisabledState(false); } else { setDisabledState(true); }

        // show/hide buyer field when country changes
        function adjustBuyerVisibility(){
            var country = (sellerSelect.value || 'United States');
            var buyerWrap = buyerSelect.closest('.form-group');
            if(country === 'Canada' || country === 'United Kingdom'){
                // hide buyer select and make country full width
                buyerWrap.style.display = 'none';
                sellerSelect.closest('.form-group').classList.add('full');
            } else {
                buyerWrap.style.display = '';
                sellerSelect.closest('.form-group').classList.remove('full');
            }
        }

        sellerSelect.addEventListener('change', function(){ adjustBuyerVisibility(); calculate(); });
        buyerSelect.addEventListener('change', calculate);
        processorSelect.addEventListener('change', calculate);
        saleInput.addEventListener('input', calculate);
        costInput.addEventListener('input', calculate);

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            localStorage.setItem('grailed_email', val);
            localStorage.setItem('grailed_email_confirmed', '1');
            setDisabledState(false);
            adjustBuyerVisibility();
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            localStorage.removeItem('grailed_email');
            localStorage.removeItem('grailed_email_confirmed');
            [sellerSelect, buyerSelect, processorSelect, saleInput, costInput].forEach(function(i){ if(i){ if(i.type==='checkbox') i.checked=false; else i.value=''; } });
            // reset buyer visibility
            adjustBuyerVisibility();
            setDisabledState(true);
            [resGrailed,resProcessing,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        function formatCurrency(val, symbol){ if(isNaN(val)) return '-'; return symbol + Number(val).toFixed(2); }

        function calculate(){
            var country = sellerSelect.value || 'United States';
            var buyer = buyerSelect.value || 'Domestic';
            var processorVal = processorSelect.value || 'Onboarded with Stripe';
            var sale = parseFloat(saleInput.value) || 0;
            var cost = parseFloat(costInput.value) || 0;

            var currency = (rates[country] && rates[country].currency) ? rates[country].currency : '$';

            // determine processing rate key
            var procKey = 'onboarded_with_stripe';
            if(processorVal.toLowerCase().indexOf('not onboarded') !== -1) procKey = 'not_onboarded_with_stripe';
            if(processorVal.toLowerCase().indexOf('stripe not eligible') !== -1) procKey = 'stripe_not_eligible';

            var buyerKey = (buyer.toLowerCase().indexOf('international') !== -1) ? 'international' : 'domestic';

            // if buyerSelect is hidden (Canada/UK), treat as domestic
            if(country === 'Canada' || country === 'United Kingdom') buyerKey = 'domestic';

            var procRate = (processingRates[procKey] && processingRates[procKey][buyerKey]) ? processingRates[procKey][buyerKey] : 0.0398;

            // Grailed fee applies to sale price (9%)
            var grailedFee = Number((sale * sellingRate).toFixed(2));
            var processingFee = Number((sale * procRate).toFixed(2));
            var totalFees = Number((grailedFee + processingFee).toFixed(2));

            var earnings = Number((sale - totalFees).toFixed(2));
            var profit = Number((earnings - cost).toFixed(2));
            var margin = 0; if(earnings !== 0) margin = Number(((profit / earnings) * 100).toFixed(1));

            resGrailed.textContent = formatCurrency(grailedFee, currency);
            resProcessing.textContent = formatCurrency(processingFee, currency);
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

        // initial adjust
        adjustBuyerVisibility();

    });
})();